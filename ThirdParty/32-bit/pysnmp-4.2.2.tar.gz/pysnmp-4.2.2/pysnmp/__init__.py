# PySNMP, version 4
majorVersionId = '4'
version = (4, 2, 1)

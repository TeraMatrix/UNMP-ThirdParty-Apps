echo " for 32 bit "
echo
echo "<++++++++++++++ START ++++++++++++++>"
rm -rf /usr/bin/python
rm -rf /usr/local/bin/python
ln -s /usr/bin/python2.6 /usr/bin/python
ln -s /usr/bin/python2.6 /usr/local/bin/python
echo " python is : python2.6 "

echo " =>Installing curl<="
mv curl-7.24.0.tar.gz.txt curl-7.24.0.tar.gz
tar -zxf curl-7.24.0.tar.gz
cd curl*
chmod 777 configure
echo "     +configure    (please be patient it will take almost 3-5 mins)"
./configure > /dev/null
echo "     +make         (please be patient it will take almost 1-3 mins)"
make > /dev/null
echo "     +make install  (please be patient it will take almost 1-2 mins)"
make install > /dev/null
rm -rf /usr/lib/libcurl.so.4
ln -s /usr/local/lib/libcurl.so.4.2.0 /usr/lib/libcurl.so.4
export LD_LIBRARY_PATH=/usr/local/lib 
#ln -s /usr/local/lib/libcurl.so.4.2.0 /usr/lib64/libcurl.so.4
echo " =>curl installed<="
cd ..
echo " =>Installing pycurl<="
tar -zxf pycurl-7.19.0.tar.gz
cd pycurl*
echo "     +setup.py install (please be patient it will take almost 1 min)"
python setup.py install > /dev/null
cd ..
echo " =>pycurl installed<="
rm -rf /usr/bin/python
rm -rf /usr/local/bin/python
ln -s /usr/bin/python2.4 /usr/bin/python
ln -s /usr/bin/python2.4 /usr/local/bin/python

echo " python is : python2.4 "
echo "<+++++++++++++ FINISHED +++++++++++++>"
echo
echo
echo " Please check that your python linking is fine "
echo " and "
echo " type following >"
echo " #python2.6 "
echo " import pycurl "
echo " done "


class PySnmpError(StandardError): pass
